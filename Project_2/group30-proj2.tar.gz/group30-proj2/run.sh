#!/bin/bash
java -cp lib/commons-codec-1.10.jar:lib/org.json.jar: Main $1 $2 $3 $4
